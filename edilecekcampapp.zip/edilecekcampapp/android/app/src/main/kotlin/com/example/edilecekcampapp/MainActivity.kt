package com.example.edilecekcampapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
